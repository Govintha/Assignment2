
public class FinalUmpair {
	int guesserNumber;
   static	int player1;
   static int player2;
   static int player3;
   static int player4;
   static	int player5;
   static int player6;
     //get number from guesser 
	int getGuesserNumer() {
		Guesser guesser=new Guesser();
		guesserNumber=guesser.getGuessNumber();
		if(guesserNumber<=9&&guesserNumber>=0)
			return 1;
		else
			return 0;			
	}
	//get number from player
	void getplayerNumber() {
		Player player01=new Player();
		if(player1!=0) {
			player1=player01.getplayerGuessingNum();
		}
		if(player2!=0) {
			player2=player01.getplayerGuessingNum();
		}
		if(player3!=0) {
			player3=player01.getplayerGuessingNum();
		}
		if(player4!=0) {
			player4=player01.getplayerGuessingNum();
		}
		if(player5!=0) {
			player5=player01.getplayerGuessingNum();
		}
		if(player6!=0) {
			player6=player01.getplayerGuessingNum();
		}

	}
	//compare the number
	void compare() {
		 if(player1==guesserNumber) {
			 if(player1==player2&&player1==player3&&player1==player4&&player1==player5&&player1==player6)
				 System.out.println("ALL ARE WINNER ");
			 else if(player1==player2)
				 System.out.println("Player 1&2 Winner");
			 else if(player1==player3)
				 System.out.println("Player 1&3 Winner");
			 else if(player1==player4)
				 System.out.println("Player 1&4 Winner");
			 else if(player1==player5)
				 System.out.println("Player 1&5 Winner");
			 else if(player1==player6)
				 System.out.println("Player 1&6 Winner");
			 else
				 System.out.println("Player 1 Winner");
		 }else if(player2==guesserNumber) {
				if(player2==player3)
					System.out.println("Player 2&3 Winner ");
				else if(player2==player4)
					System.out.println("Player 2&4 Winner ");
				else if(player2==player5)
					System.out.println("Player 2&5 Winner ");
				else if(player2==player6)
					System.out.println("Player 2&6 Winner ");
				else
					System.out.println("Player 2 Winner ");
			}else if(player3==guesserNumber) {
				if(player3==player4)
					System.out.println("Player 3&4 Winner ");
				else if(player3==player5)
					System.out.println("Player 3&5 Winner ");
				else if(player3==player6)
					System.out.println("Player 3&6 Winner ");
				else
					System.out.println("Player 3 Winner ");
			}else if(player4==guesserNumber) {
				if(player4==player5)
					System.out.println("Player 4&5 Winner ");
				else if(player4==player6)
					System.out.println("Player 4&6 Winner ");
				else
					System.out.println("Player 4 Winner ");
			}else if(player5==guesserNumber) {
				if(player5==player6)
					System.out.println("Player 5&6 Winner ");
				else 
					System.out.println("Player 5 Winner ");
			}else if(player6==guesserNumber)
				System.out.println("Player 6 Winner ");
			else
				System.out.println("No one is win");
	}
}

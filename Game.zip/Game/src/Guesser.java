import java.util.*;

public class Guesser {
     int guessNumer;
     //Guesser Pick Number
     int getGuessNumber() {
    	 Scanner sc=new  Scanner(System.in);
    	 System.out.println("Guesser Guess the Number 1 to 9 ");
    	 guessNumer=sc.nextInt();
    	 return guessNumer;
     }
}

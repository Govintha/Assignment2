//group A
public class UmpairA {
   
	int guesserNumer;
	int player1;
	int player2;
	int player3;
    
	//get the guesser Number
	int getGuesserNumer() {
		Guesser guesser=new Guesser();
		guesserNumer=guesser.getGuessNumber();
		if(guesserNumer<=9&&guesserNumer>0)
			return 1;
		else
			return 0;
					
	}
    //get player number
	void getplayerNumber() {
		Player player01=new Player();

		player1=player01.getplayerGuessingNum();
		player2=player01.getplayerGuessingNum();
		player3=player01.getplayerGuessingNum();
	}

	//Compare Number
	void compare() {

		if(player1==guesserNumer) {
			if(player1==player2&&player1==player3) {
				System.out.println("All are Winner !");
				FinalUmpair.player1=player1;
				FinalUmpair.player2=player2;
				FinalUmpair.player3=player3;
			}else if(player1==player2) {
				System.out.println("player 1&2 Winner !");
				FinalUmpair.player1=player1;
				FinalUmpair.player2=player2;
			}else if(player1==player3) {
				System.out.println("player 1&3 Winner !");
				FinalUmpair.player1=player1;
				FinalUmpair.player3=player3;
			}else {
				FinalUmpair.player1=player1;
				System.out.println("Player 1 is a Winner!");
			}

		}else if(player2==guesserNumer) {
			if(player2==player3) {
				System.out.println("Player 2&3 Winner !");
				FinalUmpair.player2=player2;
				FinalUmpair.player3=player3;
			}else {
				FinalUmpair.player2=player2;
				System.out.println("Player 2 is Winner !");
			}
		}else if(player3==guesserNumer) {
			System.out.println("Player 3 is a Winner !");
			FinalUmpair.player3=player3;
		}else {
			System.out.println("No One is winner in this Group ");
		}
	}
}

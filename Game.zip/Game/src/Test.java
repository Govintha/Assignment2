
/*
 * Guesser Game 
 * 
 *New Feature-> 
 *Total six player so we have decided into Two group A and B 
 *Two group has separate umpair who have winner they qualified for finally round 
 *they might single winner or multi winner this based on them performance 
 *we restricted and validate guesser Number The Guesser should pick 1 to 9
 *if guesser pick above 9 or blow 0 guesser again pick the number within the range  
 *we intimate to player to guess 1 to 9 in player we don't have any validate because after 
 * the intimate they give above range that player mistake 
 *Who get selected from Group A and B they qualified for final round 
 *who pick the correct number they will be winner  
 *
 */
public class Test {

	   
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=0;
		//Group A
          UmpairA umpair=new UmpairA();    
          System.out.println("Group A ");
          do{
        	   a= umpair.getGuesserNumer();
        	   if(a==1) {
        	          umpair.getplayerNumber();
        	          umpair.compare();
        	         }
        	         else
        	        	 System.out.println("Guesser you  are enter above 9 try again ");
        	         		
          }while(a==0);
          a=0;
          //Group B
          UmpairB umpairB=new UmpairB(); 
          System.out.println("Group B");
          
          do{
       	   a= umpairB.getGuesserNumer();
       	   if(a==1) {
       	          umpairB.getplayerNumber();
       	          umpairB.compare();
       	         }
       	         else
       	        	 System.out.println("Guesser you  are enter above 9 try again ");
       	         		
         }while(a==0);
          System.out.println("Final ");
          //Final
          a=0;
          FinalUmpair finalUmpair=new FinalUmpair();
          do{
          	   a= finalUmpair.getGuesserNumer();
          	   if(a==1) {
          		 finalUmpair.getplayerNumber();
          		finalUmpair.compare();
          	         }
          	         else
          	        	 System.out.println("Guesser you  are enter above 9 try again ");
          	         		
            }while(a==0);
}
}

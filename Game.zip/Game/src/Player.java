import java.util.Scanner;

public class Player {
  int playerGuessingNum;
  //player pick the number
   int getplayerGuessingNum() {
	   Scanner sc=new Scanner(System.in);
	   System.out.println("Player Guess the Numer ");
	   playerGuessingNum=sc.nextInt();
	   return playerGuessingNum;
   }
}

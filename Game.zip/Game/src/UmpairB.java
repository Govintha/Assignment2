//Group B
public class UmpairB {

	int guesserNumer;
	int player4;
	int player5;
	int player6;

//get guesser Number 
	int getGuesserNumer() {
		Guesser guesser=new Guesser();
		guesserNumer=guesser.getGuessNumber();
		if(guesserNumer<=9&&guesserNumer>0)
			return 1;
		else
			return 0;

	}
 //get player Number 
	void getplayerNumber() {
		Player player04=new Player();
		player4=player04.getplayerGuessingNum();
		player5=player04.getplayerGuessingNum();
		player6=player04.getplayerGuessingNum();
	}
// Compare the Number 
	void compare() {

		if(player4==guesserNumer) {
			if(player4==player5&&player4==player6) {
				System.out.println("All are Winner !");
				FinalUmpair.player4=player4;
				FinalUmpair.player5=player5;
				FinalUmpair.player6=player6;
			}else if(player4==player5) {
				System.out.println("player 4&5 Winner !");
				FinalUmpair.player2=player4;
				FinalUmpair.player5=player5;
			}else if(player4==player6) {
				System.out.println("player 4&6 Winner !");
				FinalUmpair.player4=player4;
				FinalUmpair.player6=player6;
			}else {
				FinalUmpair.player4=player4;
				System.out.println("Player 4 is a Winner!");
			}

		}else if(player5==guesserNumer) {
			if(player5==player6) {
				System.out.println("Player 5&6 Winner !");
				FinalUmpair.player5=player5;
				FinalUmpair.player6=player6;
			}else {
				FinalUmpair.player5=player5;
				System.out.println("Player 5 is Winner !");
			}
		}else if(player6==guesserNumer) {
			System.out.println("Player 6 is a Winner !");
			FinalUmpair.player6=player6;
		}else {
			System.out.println("No One is winner in this Group ");
		}
	}
}
